#version 300 es
precision highp float;in vec2 coord;out vec4 frag;
uniform vec2 resolution;
uniform float rotation,time,inclination,exposure,glow,scale;
float hash(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
float noise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}
float fbm(vec3 p){return .55*noise(p)+.28*noise(p*2.03)+.12*noise(p*4.07)+.05*noise(p*8.1);}
vec3 disk(vec3 p,vec3 dir){float r=length(p.xz),a=atan(p.z,p.x);float spin=time*.6/pow(r/3.,1.5)+rotation*2.;float knots=fbm(vec3(r*5.,sin(a+spin)*5.,cos(a+spin)*5.));float lanes=.82+.18*sin(r*23.+knots*5.);float temperature=pow(3./r,.75);float inner=smoothstep(3.,3.6,r);float outer=1.-smoothstep(9.,12.,r);float beam=pow(clamp(1.+dot(normalize(vec3(-p.z,0.,p.x)),-dir)*.46,.35,1.65),3.);vec3 col=mix(vec3(1.,.19,.025),vec3(1.,.90,.63),temperature);return col*(.35+knots)*lanes*pow(temperature,2.)*beam*inner*outer*2.3;}
void blackHole(vec2 p){
 float inc=inclination;vec3 ro=vec3(0.,sin(inc)*30.,cos(inc)*30.);vec3 fw=normalize(-ro),right=vec3(1,0,0),up=normalize(cross(right,fw));vec3 rd=normalize(fw+(p.x*right+p.y*up)*.42);vec3 pos=ro,vel=rd;float L2=dot(cross(ro,rd),cross(ro,rd));vec3 col=vec3(0);float trans=1.;bool captured=false;
 for(int i=0;i<220;i++){float r=length(pos);if(r<1.015){captured=true;break;}if(r>50.)break;float dt=clamp(r*.045,.025,1.2);vec3 acc=-1.5*L2*pos/pow(r,5.);vec3 next=pos+vel*dt+acc*dt*dt*.5;vel+=acc*dt;
  if(pos.y*next.y<0.){float f=pos.y/(pos.y-next.y);vec3 crossP=mix(pos,next,f);float rr=length(crossP.xz);if(rr>3.&&rr<12.){col+=disk(crossP,normalize(vel))*trans;trans*=.4;}}
  pos=next;
 }
 // The lensing shape comes from ray integration; this tiny optical bloom is a display effect.
 float lens=length(p),bloom=exp(-abs(lens-.205)*110.)*.05*glow;col+=vec3(1.,.58,.24)*bloom;
 col=vec3(1.)-exp(-col*exposure);float a=max(max(col.r,col.g),col.b);if(captured)a=1.;
 frag=vec4(col/max(a,.0001),a); // black shadow remains opaque on transparent App backgrounds
}
void main(){vec2 p=coord*resolution/min(resolution.x,resolution.y)/scale;blackHole(p);}
